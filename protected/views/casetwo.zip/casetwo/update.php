<?php
/* @var $this CasetwoController */
/* @var $model Casetwo */

$this->breadcrumbs=array(
	'Casetwos'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Case two', 'url'=>array('index')),
	array('label'=>'Create Case two', 'url'=>array('create')),
	array('label'=>'View Case two', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Case two', 'url'=>array('admin')),
);
?>

<h1>Update Case two <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>