<?php
/* @var $this CasetwoController */
/* @var $model Casetwo */

$this->breadcrumbs=array(
	'Case twos'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Case two', 'url'=>array('index')),
	array('label'=>'Manage Case two', 'url'=>array('admin')),
);
?>

<h1>Create Case two</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>