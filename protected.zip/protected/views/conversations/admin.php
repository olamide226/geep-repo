<?php
/* @var $this ConversationsController */
/* @var $model Conversations */

$this->breadcrumbs=array(
	'Conversations'=>array('index'),
	'Manage',
);

$this->menu=array(
    array('label'=>'Back', 'url'=>array('boi/admin')),
	//array('label'=>'List Conversations', 'url'=>array('index')),
	//array('label'=>'Create Conversations', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#conversations-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Loans and Reconciliation comments</h1>

<p>
You may optionally enter a comparison operator (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) at the beginning of each of your search values to specify how the comparison should be done.
</p>

<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'conversations-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		//'id',
		//'boi_id',
		'comment',
		'other_comments',
		'comment_by',
        'member_id',
        'created_on',

		/*
		'date',
		'phone_number',
		'amount',
		'source',
		'categories',
		'agent_name',
		'date_paid',

		*/
		array(
			'class'=>'CButtonColumn',
            'template' => '{update}',

		),
	),
)); ?>
