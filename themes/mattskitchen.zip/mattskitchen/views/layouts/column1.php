<?php $this->beginContent('//layouts/main'); ?>
<section id="content">
	<?php echo $content; ?>
</section><!-- content -->
<?php $this->endContent(); ?>
